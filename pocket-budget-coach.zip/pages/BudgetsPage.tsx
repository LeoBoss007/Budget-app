
import React, { useState } from 'react';
import { Row, Col } from 'react-bootstrap';
import { useAppContext } from '../contexts/AppContext';
import { Budget, BudgetPeriod, TransactionType } from '../types';
import { EXPENSE_CATEGORIES } from '../constants';
import { formatCurrency } from '../utils/currencyUtils';
import Card from '../components/ui/Card';
import Button from '../components/ui/Button';
import Modal from '../components/ui/Modal';
import Input from '../components/ui/Input';
import Select from '../components/ui/Select';
import ProgressBar from '../components/ui/ProgressBar';

interface BudgetFormProps {
  onSubmit: (budget: Omit<Budget, 'id'>) => void;
  onClose: () => void;
}

const BudgetForm: React.FC<BudgetFormProps> = ({ onSubmit, onClose }) => {
  const [category, setCategory] = useState(EXPENSE_CATEGORIES[0]);
  const [limit, setLimit] = useState('');
  const [period, setPeriod] = useState<BudgetPeriod>(BudgetPeriod.MONTHLY);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSubmit({ category, limit: parseFloat(limit), period });
    onClose();
  };

  return (
    <form onSubmit={handleSubmit} className="d-flex flex-column gap-3">
      <Select
        label="Category"
        id="budget-category"
        options={EXPENSE_CATEGORIES}
        value={category}
        onChange={e => setCategory(e.target.value)}
      />
      <Input
        label="Limit"
        id="budget-limit"
        type="number"
        value={limit}
        onChange={e => setLimit(e.target.value)}
        required
      />
      <Select
        label="Period"
        id="budget-period"
        options={Object.values(BudgetPeriod)}
        value={period}
        onChange={e => setPeriod(e.target.value as BudgetPeriod)}
      />
      <div className="d-flex justify-content-end pt-3 gap-2">
        <Button variant="secondary" onClick={onClose}>Cancel</Button>
        <Button type="submit">Set Budget</Button>
      </div>
    </form>
  );
};

const BudgetsPage: React.FC = () => {
  const { budgets, addBudget, deleteBudget, transactions, currency } = useAppContext();
  const [isModalOpen, setIsModalOpen] = useState(false);

  return (
    <div className="d-flex flex-column gap-4">
      <div className="d-flex justify-content-between align-items-center">
        <h1 className="h2 fw-bold text-dark">Budgets</h1>
        <Button onClick={() => setIsModalOpen(true)}>
          <i className="fas fa-plus me-2"></i>
          Set Budget
        </Button>
      </div>

      {budgets.length === 0 ? (
        <Card>
          <p className="text-center text-muted">You haven't set any budgets yet.</p>
        </Card>
      ) : (
        <Row xs={1} md={2} className="g-4">
          {budgets.map(budget => {
            const spent = transactions
              .filter(t => t.type === TransactionType.EXPENSE && t.category === budget.category)
              .reduce((sum, t) => sum + t.amount, 0);
            const progress = (spent / budget.limit) * 100;
            const progressColor = progress > 100 ? 'red' : progress > 75 ? 'yellow' : 'green';

            return (
              <Col key={budget.id}>
                <Card title={budget.category}>
                  <div className="d-flex flex-column gap-2">
                    <ProgressBar value={progress} color={progressColor} />
                    <div className="d-flex justify-content-between small">
                      <span className="fw-semibold text-dark">{formatCurrency(spent, currency)} spent</span>
                      <span className="text-muted">of {formatCurrency(budget.limit, currency)}</span>
                    </div>
                    <div className="small text-muted text-capitalize">{budget.period.toLowerCase()}</div>
                    <div className="text-end">
                      <Button variant="danger" size="sm" onClick={() => deleteBudget(budget.id)}>
                        <i className="fas fa-trash-alt"></i>
                      </Button>
                    </div>
                  </div>
                </Card>
              </Col>
            );
          })}
        </Row>
      )}

      <Modal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        title="Set New Budget"
      >
        <BudgetForm onSubmit={addBudget} onClose={() => setIsModalOpen(false)} />
      </Modal>
    </div>
  );
};

export default BudgetsPage;
