
import React, { useMemo } from 'react';
import { Row, Col } from 'react-bootstrap';
import { useAppContext } from '../contexts/AppContext';
import { calculateBalance, calculateTotal } from '../utils/financialUtils';
import { formatCurrency } from '../utils/currencyUtils';
import { TransactionType } from '../types';
import Card from '../components/ui/Card';
import ProgressBar from '../components/ui/ProgressBar';

interface SummaryCardProps {
    title: string;
    amount: number;
    colorClasses: { bg: string, text: string };
    icon: string
}

const SummaryCard: React.FC<SummaryCardProps> = ({ title, amount, colorClasses, icon }) => {
  const { currency } = useAppContext();
  return (
    <Card>
      <div className="d-flex align-items-center">
        <div className={`p-3 rounded-circle me-3 ${colorClasses.bg}`}>
          <i className={`fas ${icon} fa-lg ${colorClasses.text}`}></i>
        </div>
        <div>
          <p className="text-muted mb-0">{title}</p>
          <p className="h4 fw-bold text-dark mb-0">{formatCurrency(amount, currency)}</p>
        </div>
      </div>
    </Card>
  );
};

const Dashboard: React.FC = () => {
  const { transactions, budgets, savingsGoals, currency } = useAppContext();

  const totalIncome = useMemo(() => calculateTotal(transactions, TransactionType.INCOME), [transactions]);
  const totalExpenses = useMemo(() => calculateTotal(transactions, TransactionType.EXPENSE), [transactions]);
  const totalSavings = useMemo(() => calculateTotal(transactions, TransactionType.SAVING), [transactions]);
  const balance = useMemo(() => calculateBalance(transactions), [transactions]);

  return (
    <div className="d-flex flex-column gap-4">
      <h1 className="h2 fw-bold text-dark">Dashboard</h1>
      
      <Row xs={1} md={2} xl={4} className="g-4">
        <Col>
          <SummaryCard title="Total Balance" amount={balance} colorClasses={balance >= 0 ? {bg: 'bg-primary-subtle', text: 'text-primary'} : {bg: 'bg-danger-subtle', text: 'text-danger'}} icon="fa-balance-scale" />
        </Col>
        <Col>
          <SummaryCard title="Total Income" amount={totalIncome} colorClasses={{bg: 'bg-success-subtle', text: 'text-success'}} icon="fa-arrow-up" />
        </Col>
        <Col>
          <SummaryCard title="Total Expenses" amount={totalExpenses} colorClasses={{bg: 'bg-danger-subtle', text: 'text-danger'}} icon="fa-arrow-down" />
        </Col>
        <Col>
          <SummaryCard title="Total Savings" amount={totalSavings} colorClasses={{bg: 'bg-info-subtle', text: 'text-info'}} icon="fa-piggy-bank" />
        </Col>
      </Row>

      <Row xs={1} lg={2} className="g-4">
        <Col>
          <Card title="Budgets Overview">
            {budgets.length > 0 ? (
              <div className="d-flex flex-column gap-3">
                {budgets.map(budget => {
                  const spent = transactions
                    .filter(t => t.type === TransactionType.EXPENSE && t.category === budget.category)
                    .reduce((sum, t) => sum + t.amount, 0);
                  const progress = (spent / budget.limit) * 100;
                  const progressColor = progress > 100 ? 'red' : progress > 75 ? 'yellow' : 'green';

                  return (
                    <div key={budget.id}>
                      <div className="d-flex justify-content-between mb-1">
                        <span className="fw-medium">{budget.category}</span>
                        <span className="small text-muted">{formatCurrency(spent, currency)} / {formatCurrency(budget.limit, currency)}</span>
                      </div>
                      <ProgressBar value={progress} color={progressColor} />
                    </div>
                  );
                })}
              </div>
            ) : (
              <p className="text-center text-muted">No budgets set yet.</p>
            )}
          </Card>
        </Col>
        <Col>
          <Card title="Savings Goals">
            {savingsGoals.length > 0 ? (
               <div className="d-flex flex-column gap-3">
                {savingsGoals.map(goal => {
                  const progress = (goal.currentAmount / goal.targetAmount) * 100;
                  return (
                    <div key={goal.id}>
                      <div className="d-flex justify-content-between mb-1">
                        <span className="fw-medium">{goal.name}</span>
                        <span className="small text-muted">{formatCurrency(goal.currentAmount, currency)} / {formatCurrency(goal.targetAmount, currency)}</span>
                      </div>
                      <ProgressBar value={progress} color="blue" />
                    </div>
                  );
                })}
              </div>
            ) : (
              <p className="text-center text-muted">No savings goals created yet.</p>
            )}
          </Card>
        </Col>
      </Row>
    </div>
  );
};

export default Dashboard;
