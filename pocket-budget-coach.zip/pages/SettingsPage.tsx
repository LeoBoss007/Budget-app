
import React from 'react';
import { useAppContext } from '../contexts/AppContext';
import { Currency } from '../types';
import { CURRENCIES } from '../constants';
import Card from '../components/ui/Card';
import Select from '../components/ui/Select';

const SettingsPage: React.FC = () => {
  const { currency, setCurrency } = useAppContext();

  const handleCurrencyChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    setCurrency(e.target.value as Currency);
  };

  return (
    <div className="d-flex flex-column gap-4">
      <h1 className="h2 fw-bold text-dark">Settings</h1>
      <Card title="Preferences">
        <div style={{ maxWidth: '20rem' }}>
          <Select
            label="Currency"
            id="currency-select"
            options={Object.keys(CURRENCIES)}
            value={currency}
            onChange={handleCurrencyChange}
            getOptionLabel={option => `${option} (${CURRENCIES[option as Currency]})`}
          />
        </div>
      </Card>
    </div>
  );
};

export default SettingsPage;
