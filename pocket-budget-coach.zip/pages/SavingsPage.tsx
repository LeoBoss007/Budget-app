
import React, { useState } from 'react';
import { Row, Col } from 'react-bootstrap';
import { useAppContext } from '../contexts/AppContext';
import { SavingsGoal, TransactionType } from '../types';
import { formatCurrency } from '../utils/currencyUtils';
import Card from '../components/ui/Card';
import Button from '../components/ui/Button';
import Modal from '../components/ui/Modal';
import Input from '../components/ui/Input';
import ProgressBar from '../components/ui/ProgressBar';

interface SavingsGoalFormProps {
  onSubmit: (goal: Omit<SavingsGoal, 'id' | 'currentAmount'>) => void;
  onClose: () => void;
}

const SavingsGoalForm: React.FC<SavingsGoalFormProps> = ({ onSubmit, onClose }) => {
  const [name, setName] = useState('');
  const [targetAmount, setTargetAmount] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSubmit({ name, targetAmount: parseFloat(targetAmount) });
    onClose();
  };

  return (
    <form onSubmit={handleSubmit} className="d-flex flex-column gap-3">
      <Input label="Goal Name" id="goal-name" type="text" value={name} onChange={e => setName(e.target.value)} required />
      <Input label="Target Amount" id="target-amount" type="number" value={targetAmount} onChange={e => setTargetAmount(e.target.value)} required />
      <div className="d-flex justify-content-end pt-3 gap-2">
        <Button variant="secondary" onClick={onClose}>Cancel</Button>
        <Button type="submit">Create Goal</Button>
      </div>
    </form>
  );
};

const SavingsPage: React.FC = () => {
  const { savingsGoals, addSavingsGoal, updateSavingsGoal, deleteSavingsGoal, addTransaction, currency } = useAppContext();
  const [isCreateModalOpen, setCreateModalOpen] = useState(false);
  const [isWithdrawModalOpen, setWithdrawModalOpen] = useState(false);
  const [selectedGoal, setSelectedGoal] = useState<SavingsGoal | null>(null);
  const [withdrawAmount, setWithdrawAmount] = useState('');

  const handleAddGoal = (goal: Omit<SavingsGoal, 'id' | 'currentAmount'>) => {
    addSavingsGoal({ ...goal, currentAmount: 0 });
  };
  
  const openWithdrawModal = (goal: SavingsGoal) => {
    setSelectedGoal(goal);
    setWithdrawModalOpen(true);
  };
  
  const handleWithdraw = (e: React.FormEvent) => {
    e.preventDefault();
    const amount = parseFloat(withdrawAmount);
    if (selectedGoal && !isNaN(amount) && amount > 0) {
      if (amount > selectedGoal.currentAmount) {
        alert("Cannot withdraw more than the saved amount.");
        return;
      }
      updateSavingsGoal({ ...selectedGoal, currentAmount: selectedGoal.currentAmount - amount });
      addTransaction({
        type: TransactionType.INCOME,
        amount,
        category: 'Savings Withdrawal',
        date: new Date().toISOString().split('T')[0],
        description: `Withdrew from ${selectedGoal.name}`,
      });
      setWithdrawModalOpen(false);
      setSelectedGoal(null);
      setWithdrawAmount('');
    }
  };

  return (
    <div className="d-flex flex-column gap-4">
      <div className="d-flex justify-content-between align-items-center">
        <h1 className="h2 fw-bold text-dark">Savings Goals</h1>
        <Button onClick={() => setCreateModalOpen(true)}>
          <i className="fas fa-plus me-2"></i>
          New Goal
        </Button>
      </div>

      {savingsGoals.length === 0 ? (
        <Card><p className="text-center text-muted">No savings goals yet. Create one to start saving!</p></Card>
      ) : (
        <Row xs={1} md={2} className="g-4">
          {savingsGoals.map(goal => {
            const progress = goal.targetAmount > 0 ? (goal.currentAmount / goal.targetAmount) * 100 : 0;
            return (
              <Col key={goal.id}>
                <Card title={goal.name}>
                  <div className="d-flex flex-column gap-3">
                      <ProgressBar value={progress} color="blue" />
                      <div className="d-flex justify-content-between small">
                          <span className="fw-semibold text-dark">{formatCurrency(goal.currentAmount, currency)}</span>
                          <span className="text-muted">of {formatCurrency(goal.targetAmount, currency)}</span>
                      </div>
                      <div className="d-flex justify-content-end gap-2">
                          <Button size="sm" variant="outline-secondary" onClick={() => openWithdrawModal(goal)}>- Withdraw</Button>
                          <Button size="sm" variant="danger" onClick={() => deleteSavingsGoal(goal.id)}><i className="fas fa-trash-alt"></i></Button>
                      </div>
                  </div>
                </Card>
              </Col>
            );
          })}
        </Row>
      )}

      <Modal isOpen={isCreateModalOpen} onClose={() => setCreateModalOpen(false)} title="Create Savings Goal">
        <SavingsGoalForm onSubmit={handleAddGoal} onClose={() => setCreateModalOpen(false)} />
      </Modal>

      <Modal isOpen={isWithdrawModalOpen} onClose={() => setWithdrawModalOpen(false)} title={`Withdraw from ${selectedGoal?.name}`}>
        <form onSubmit={handleWithdraw} className="d-flex flex-column gap-3">
            <Input label="Amount to Withdraw" id="withdraw-amount" type="number" value={withdrawAmount} onChange={e => setWithdrawAmount(e.target.value)} required max={selectedGoal?.currentAmount} />
            <div className="d-flex justify-content-end pt-3 gap-2">
                <Button variant="secondary" onClick={() => setWithdrawModalOpen(false)}>Cancel</Button>
                <Button type="submit">Withdraw</Button>
            </div>
        </form>
      </Modal>
    </div>
  );
};

export default SavingsPage;
