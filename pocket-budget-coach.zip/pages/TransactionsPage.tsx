
import React, { useState } from 'react';
import { useAppContext } from '../contexts/AppContext';
import { Transaction } from '../types';
import TransactionList from '../components/TransactionList';
import TransactionForm from '../components/TransactionForm';
import Modal from '../components/ui/Modal';
import Button from '../components/ui/Button';

const TransactionsPage: React.FC = () => {
  const { transactions, addTransaction, updateTransaction, deleteTransaction } = useAppContext();
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingTransaction, setEditingTransaction] = useState<Transaction | null>(null);

  const handleOpenModal = () => {
    setEditingTransaction(null);
    setIsModalOpen(true);
  };

  const handleCloseModal = () => {
    setIsModalOpen(false);
    setEditingTransaction(null);
  };

  const handleEdit = (transaction: Transaction) => {
    setEditingTransaction(transaction);
    setIsModalOpen(true);
  };

  return (
    <div className="d-flex flex-column gap-4">
      <div className="d-flex justify-content-between align-items-center">
        <h1 className="h2 fw-bold text-dark">Transactions</h1>
        <Button onClick={handleOpenModal}>
          <i className="fas fa-plus me-2"></i>
          Add Transaction
        </Button>
      </div>

      <TransactionList
        transactions={transactions}
        onEdit={handleEdit}
        onDelete={deleteTransaction}
      />

      <Modal
        isOpen={isModalOpen}
        onClose={handleCloseModal}
        title={editingTransaction ? "Edit Transaction" : "Add Transaction"}
      >
        <TransactionForm
          onSubmit={addTransaction}
          onUpdate={updateTransaction}
          existingTransaction={editingTransaction}
          onClose={handleCloseModal}
        />
      </Modal>
    </div>
  );
};

export default TransactionsPage;
