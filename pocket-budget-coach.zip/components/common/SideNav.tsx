
import React from 'react';
import { Nav } from 'react-bootstrap';
import { Page } from '../../types';

interface SideNavProps {
  activePage: Page;
  setActivePage: (page: Page) => void;
}

const NavItem: React.FC<{ icon: string; label: string; page: Page; activePage: Page; onClick: (page: Page) => void }> = ({ icon, label, page, activePage, onClick }) => {
  const isActive = activePage === page;
  
  return (
    <Nav.Item as="li">
      <Nav.Link onClick={() => onClick(page)} active={isActive} className="d-flex align-items-center p-3">
        <i className={`fas ${icon} fa-lg text-center`} style={{width: '2rem'}}></i>
        <span className="ms-3">{label}</span>
      </Nav.Link>
    </Nav.Item>
  );
};

const SideNav: React.FC<SideNavProps> = ({ activePage, setActivePage }) => {
  return (
    <aside className="d-none d-md-flex flex-column bg-white border-end" style={{width: '280px', flexShrink: 0}}>
      <div className="d-flex align-items-center justify-content-center border-bottom" style={{height: '60px'}}>
        <h1 className="h5 fw-bold text-primary mb-0">
          <i className="fas fa-wallet me-2"></i>
          Pocket Coach
        </h1>
      </div>
      <Nav as="ul" className="flex-column flex-grow-1 p-2">
        <NavItem icon="fa-chart-pie" label="Dashboard" page="dashboard" activePage={activePage} onClick={setActivePage} />
        <NavItem icon="fa-exchange-alt" label="Transactions" page="transactions" activePage={activePage} onClick={setActivePage} />
        <NavItem icon="fa-bullseye" label="Budgets" page="budgets" activePage={activePage} onClick={setActivePage} />
        <NavItem icon="fa-piggy-bank" label="Savings" page="savings" activePage={activePage} onClick={setActivePage} />
        <NavItem icon="fa-cog" label="Settings" page="settings" activePage={activePage} onClick={setActivePage} />
      </Nav>
    </aside>
  );
};

export default SideNav;
