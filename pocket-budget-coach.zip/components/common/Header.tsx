
import React from 'react';

const Header: React.FC = () => {
  return (
    <header className="bg-white shadow-sm sticky-top d-md-none border-bottom">
      <div className="container-fluid p-3" style={{ height: '60px' }}>
        <h1 className="h5 fw-bold text-primary text-center mb-0">
          <i className="fas fa-wallet me-2"></i>
          Pocket Coach
        </h1>
      </div>
    </header>
  );
};

export default Header;
