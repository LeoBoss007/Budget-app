
import React from 'react';
import { Nav, Navbar } from 'react-bootstrap';
import { Page } from '../../types';

interface BottomNavProps {
  activePage: Page;
  setActivePage: (page: Page) => void;
}

const NavItem: React.FC<{ icon: string; label: string; page: Page; activePage: Page; onClick: (page: Page) => void }> = ({ icon, label, page, activePage, onClick }) => {
  const isActive = activePage === page;
  
  return (
    <Nav.Link onClick={() => onClick(page)} active={isActive} className="d-flex flex-column align-items-center text-center p-2">
      <i className={`fas ${icon} fa-lg mb-1`}></i>
      <span className="small">{label}</span>
    </Nav.Link>
  );
};

const BottomNav: React.FC<BottomNavProps> = ({ activePage, setActivePage }) => {
  return (
    <Navbar bg="light" fixed="bottom" className="border-top d-md-none">
      <Nav className="w-100 justify-content-around">
        <NavItem icon="fa-chart-pie" label="Dashboard" page="dashboard" activePage={activePage} onClick={setActivePage} />
        <NavItem icon="fa-exchange-alt" label="Transactions" page="transactions" activePage={activePage} onClick={setActivePage} />
        <NavItem icon="fa-bullseye" label="Budgets" page="budgets" activePage={activePage} onClick={setActivePage} />
        <NavItem icon="fa-piggy-bank" label="Savings" page="savings" activePage={activePage} onClick={setActivePage} />
        <NavItem icon="fa-cog" label="Settings" page="settings" activePage={activePage} onClick={setActivePage} />
      </Nav>
    </Navbar>
  );
};

export default BottomNav;
