
import React, { useState, useEffect } from 'react';
import { ButtonGroup } from 'react-bootstrap';
import { Transaction, TransactionType } from '../types';
import { INCOME_CATEGORIES, EXPENSE_CATEGORIES } from '../constants';
import { getISODate } from '../utils/dateUtils';
import { useAppContext } from '../contexts/AppContext';
import Input from './ui/Input';
import Select from './ui/Select';
import Button from './ui/Button';

interface TransactionFormProps {
  onSubmit: (transaction: Omit<Transaction, 'id'>) => void;
  onUpdate: (transaction: Transaction) => void;
  existingTransaction?: Transaction | null;
  onClose: () => void;
}

const TransactionForm: React.FC<TransactionFormProps> = ({ onSubmit, onUpdate, existingTransaction, onClose }) => {
  const { savingsGoals } = useAppContext();
  const [type, setType] = useState<TransactionType>(TransactionType.EXPENSE);
  const [amount, setAmount] = useState('');
  const [category, setCategory] = useState('');
  const [date, setDate] = useState(getISODate());
  const [description, setDescription] = useState('');
  const [savingsGoalId, setSavingsGoalId] = useState<string | undefined>(undefined);

  const categories = type === TransactionType.INCOME ? INCOME_CATEGORIES : EXPENSE_CATEGORIES;

  useEffect(() => {
    if (existingTransaction) {
      setType(existingTransaction.type);
      setAmount(String(existingTransaction.amount));
      setCategory(existingTransaction.category);
      setDate(existingTransaction.date);
      setDescription(existingTransaction.description);
      setSavingsGoalId(existingTransaction.savingsGoalId);
    } else {
      setType(TransactionType.EXPENSE);
      setAmount('');
      setCategory(EXPENSE_CATEGORIES[0]);
      setDate(getISODate());
      setDescription('');
      setSavingsGoalId(undefined);
    }
  }, [existingTransaction]);

  useEffect(() => {
    if (type !== TransactionType.SAVING) {
      setCategory(categories[0] || '');
      setSavingsGoalId(undefined);
    } else {
      setCategory('Savings Contribution');
      if (savingsGoals.length > 0) {
        setSavingsGoalId(savingsGoals[0].id);
      }
    }
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [type, savingsGoals]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (type === TransactionType.SAVING && !savingsGoalId) {
        alert("Please select a savings goal.");
        return;
    }

    const transactionData = {
      type,
      amount: parseFloat(amount),
      category: type === TransactionType.SAVING ? 'Savings Contribution' : category,
      date,
      description,
      savingsGoalId,
    };

    if (existingTransaction) {
      onUpdate({ ...transactionData, id: existingTransaction.id });
    } else {
      onSubmit(transactionData);
    }
    onClose();
  };
  
  const hasSavingsGoals = savingsGoals.length > 0;

  return (
    <form onSubmit={handleSubmit} className="d-flex flex-column gap-3">
      <ButtonGroup className="w-100">
        <Button onClick={() => setType(TransactionType.EXPENSE)} variant={type === TransactionType.EXPENSE ? 'danger' : 'outline-secondary'}>Expense</Button>
        <Button onClick={() => setType(TransactionType.INCOME)} variant={type === TransactionType.INCOME ? 'success' : 'outline-secondary'}>Income</Button>
        <Button onClick={() => setType(TransactionType.SAVING)} variant={type === TransactionType.SAVING ? 'primary' : 'outline-secondary'} disabled={!hasSavingsGoals} title={!hasSavingsGoals ? "Create a savings goal first" : ""}>Saving</Button>
      </ButtonGroup>
      <Input label="Amount" id="amount" type="number" value={amount} onChange={e => setAmount(e.target.value)} required step="0.01" />
      
      {type === TransactionType.SAVING ? (
        <Select label="Savings Goal" id="savings-goal" options={savingsGoals.map(g => g.id)} value={savingsGoalId} onChange={e => setSavingsGoalId(e.target.value)} getOptionLabel={option => savingsGoals.find(g=>g.id === option)?.name}/>
      ) : (
        <Select label="Category" id="category" options={categories} value={category} onChange={e => setCategory(e.target.value)} required />
      )}
      
      <Input label="Date" id="date" type="date" value={date} onChange={e => setDate(e.target.value)} required />
      <Input label="Description (Optional)" id="description" type="text" value={description} onChange={e => setDescription(e.target.value)} />
      
      <div className="d-flex justify-content-end pt-3 gap-2">
        <Button variant="secondary" onClick={onClose}>Cancel</Button>
        <Button type="submit">{existingTransaction ? 'Update' : 'Add'} Transaction</Button>
      </div>
    </form>
  );
};

export default TransactionForm;
