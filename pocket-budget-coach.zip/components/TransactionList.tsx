
import React from 'react';
import { ListGroup } from 'react-bootstrap';
import { Transaction, TransactionType } from '../types';
import { formatDate } from '../utils/dateUtils';
import { formatCurrency } from '../utils/currencyUtils';
import { useAppContext } from '../contexts/AppContext';
import Card from './ui/Card';

interface TransactionListProps {
  transactions: Transaction[];
  onEdit: (transaction: Transaction) => void;
  onDelete: (id: string) => void;
  limit?: number;
}

const TransactionItem: React.FC<{ transaction: Transaction; onEdit: (transaction: Transaction) => void; onDelete: (id: string) => void; }> = ({ transaction, onEdit, onDelete }) => {
  const { currency } = useAppContext();
  const isIncome = transaction.type === TransactionType.INCOME;

  let amountClass = isIncome ? 'text-success' : 'text-danger';
  let sign = isIncome ? '+' : '-';
  let icon = isIncome ? 'fa-arrow-up' : 'fa-arrow-down';
  let iconBgClass = isIncome ? 'bg-success-subtle' : 'bg-danger-subtle';

  if (transaction.type === TransactionType.SAVING) {
    amountClass = 'text-primary';
    icon = 'fa-piggy-bank';
    iconBgClass = 'bg-primary-subtle';
  }

  return (
    <ListGroup.Item as="li" className="d-flex align-items-center justify-content-between py-3 px-2">
      <div className="d-flex align-items-center">
        <div className={`d-flex align-items-center justify-content-center rounded-circle me-3 ${iconBgClass}`} style={{ width: '40px', height: '40px' }}>
            <i className={`fas ${icon} ${amountClass}`}></i>
        </div>
        <div>
          <p className="fw-semibold text-dark mb-0">{transaction.category}</p>
          <p className="small text-muted mb-0">{transaction.description || formatDate(transaction.date)}</p>
        </div>
      </div>
      <div className="text-end">
        <p className={`fw-bold mb-0 ${amountClass}`}>{`${sign}${formatCurrency(transaction.amount, currency)}`}</p>
        <div className="small text-muted">
            <button onClick={() => onEdit(transaction)} className="btn btn-sm btn-link text-decoration-none me-1"><i className="fas fa-pencil-alt"></i></button>
            <button onClick={() => onDelete(transaction.id)} className="btn btn-sm btn-link text-decoration-none text-danger"><i className="fas fa-trash-alt"></i></button>
        </div>
      </div>
    </ListGroup.Item>
  );
};

const TransactionList: React.FC<TransactionListProps> = ({ transactions, onEdit, onDelete, limit }) => {
  const sortedTransactions = [...transactions].sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
  const displayTransactions = limit ? sortedTransactions.slice(0, limit) : sortedTransactions;
  
  if (displayTransactions.length === 0) {
    return (
      <Card>
        <p className="text-center text-muted">No transactions yet. Add one to get started!</p>
      </Card>
    );
  }

  return (
    <Card>
      <ListGroup variant="flush">
        {displayTransactions.map(t => (
          <TransactionItem key={t.id} transaction={t} onEdit={onEdit} onDelete={onDelete} />
        ))}
      </ListGroup>
    </Card>
  );
};

export default TransactionList;
