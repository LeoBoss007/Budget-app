
import React from 'react';
import { ProgressBar as BootstrapProgressBar } from 'react-bootstrap';

interface ProgressBarProps {
  value: number; // 0 to 100
  color?: 'green' | 'blue' | 'yellow' | 'red';
}

const ProgressBar: React.FC<ProgressBarProps> = ({ value, color = 'blue' }) => {
  const cappedValue = Math.min(Math.max(value, 0), 100);
  
  const variantMapping: { [key: string]: string } = {
    green: 'success',
    blue: 'primary',
    yellow: 'warning',
    red: 'danger',
  };

  return <BootstrapProgressBar now={cappedValue} variant={variantMapping[color]} />;
};

export default ProgressBar;
