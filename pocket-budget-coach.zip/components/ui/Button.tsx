import React from 'react';
import { Button as BootstrapButton, ButtonProps as BootstrapButtonProps } from 'react-bootstrap';

// The react-bootstrap ButtonProps already include variant, size, and children.
interface ButtonProps extends BootstrapButtonProps {
  // Custom props can be added here if needed
}

// FIX: Destructuring the polymorphic 'as' prop in the function signature resolves a TypeScript type inference issue.
// This prevents type conflicts when spreading props onto generic components like react-bootstrap's Button.
const Button: React.FC<ButtonProps> = ({ as, ...props }) => {
  return <BootstrapButton as={as} {...props} />;
};

export default Button;