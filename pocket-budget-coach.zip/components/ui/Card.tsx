
import React, { ReactNode } from 'react';
import { Card as BootstrapCard } from 'react-bootstrap';

interface CardProps {
  children: ReactNode;
  className?: string;
  title?: string;
}

const Card: React.FC<CardProps> = ({ children, className = '', title }) => {
  return (
    <BootstrapCard className={className}>
      {title && (
        <BootstrapCard.Header as="h2" className="h5">{title}</BootstrapCard.Header>
      )}
      <BootstrapCard.Body>
        {children}
      </BootstrapCard.Body>
    </BootstrapCard>
  );
};

export default Card;
