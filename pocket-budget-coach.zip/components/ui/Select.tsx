
import React, { SelectHTMLAttributes } from 'react';
import { Form } from 'react-bootstrap';

interface SelectProps extends Omit<SelectHTMLAttributes<HTMLSelectElement>, 'size'> {
  label: string;
  options: string[];
  getOptionLabel?: (option: string) => string | undefined;
  size?: 'sm' | 'lg';
}

const Select: React.FC<SelectProps> = ({ label, id, options, getOptionLabel, ...props }) => {
  return (
    <Form.Group controlId={id}>
      <Form.Label>{label}</Form.Label>
      <Form.Select {...props}>
        {options.map(option => (
          <option key={option} value={option}>{getOptionLabel ? getOptionLabel(option) : option}</option>
        ))}
      </Form.Select>
    </Form.Group>
  );
};

export default Select;
