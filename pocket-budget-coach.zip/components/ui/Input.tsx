import React, { InputHTMLAttributes } from 'react';
import { Form } from 'react-bootstrap';

// Omit 'size' to avoid conflict between HTML attribute (number) and react-bootstrap prop (string)
// FIX: Omit and re-define 'value' to be compatible with react-bootstrap's FormControlProps.
// This resolves a type mismatch between HTMLInputElement's 'readonly string[]'
// and FormControl's mutable 'string[]' for the value prop.
interface InputProps extends Omit<InputHTMLAttributes<HTMLInputElement>, 'size' | 'value'> {
  label?: string;
  size?: 'sm' | 'lg';
  value?: string | string[] | number;
}

const Input: React.FC<InputProps> = ({ label, id, ...props }) => {
  return (
    <Form.Group controlId={id}>
      {label && <Form.Label>{label}</Form.Label>}
      <Form.Control {...props} />
    </Form.Group>
  );
};

export default Input;