
import React, { createContext, useContext, ReactNode } from 'react';
import { useLocalStorage } from '../hooks/useLocalStorage';
import { Transaction, Budget, SavingsGoal, TransactionType, Currency } from '../types';

interface AppContextType {
  transactions: Transaction[];
  setTransactions: React.Dispatch<React.SetStateAction<Transaction[]>>;
  addTransaction: (transaction: Omit<Transaction, 'id'>) => void;
  updateTransaction: (transaction: Transaction) => void;
  deleteTransaction: (id: string) => void;

  budgets: Budget[];
  setBudgets: React.Dispatch<React.SetStateAction<Budget[]>>;
  addBudget: (budget: Omit<Budget, 'id'>) => void;
  updateBudget: (budget: Budget) => void;
  deleteBudget: (id: string) => void;

  savingsGoals: SavingsGoal[];
  setSavingsGoals: React.Dispatch<React.SetStateAction<SavingsGoal[]>>;
  addSavingsGoal: (goal: Omit<SavingsGoal, 'id'>) => void;
  updateSavingsGoal: (goal: SavingsGoal) => void;
  deleteSavingsGoal: (id: string) => void;

  currency: Currency;
  setCurrency: React.Dispatch<React.SetStateAction<Currency>>;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export const AppProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [transactions, setTransactions] = useLocalStorage<Transaction[]>('transactions', []);
  const [budgets, setBudgets] = useLocalStorage<Budget[]>('budgets', []);
  const [savingsGoals, setSavingsGoals] = useLocalStorage<SavingsGoal[]>('savingsGoals', []);
  const [currency, setCurrency] = useLocalStorage<Currency>('currency', 'USD');

  const addTransaction = (transaction: Omit<Transaction, 'id'>) => {
    const newTransaction = { ...transaction, id: crypto.randomUUID() };
    setTransactions(prev => [...prev, newTransaction]);

    if (newTransaction.type === TransactionType.SAVING && newTransaction.savingsGoalId) {
      setSavingsGoals(prevGoals => prevGoals.map(goal => 
        goal.id === newTransaction.savingsGoalId 
          ? { ...goal, currentAmount: goal.currentAmount + newTransaction.amount }
          : goal
      ));
    }
  };

  const updateTransaction = (updatedTransaction: Transaction) => {
    const oldTransaction = transactions.find(t => t.id === updatedTransaction.id);
    
    setTransactions(prev => prev.map(t => t.id === updatedTransaction.id ? updatedTransaction : t));

    if (oldTransaction?.type === TransactionType.SAVING && oldTransaction.savingsGoalId) {
      // Revert old transaction amount from goal
      setSavingsGoals(prevGoals => prevGoals.map(goal => 
        goal.id === oldTransaction.savingsGoalId
          ? { ...goal, currentAmount: goal.currentAmount - oldTransaction.amount }
          : goal
      ));
    }
    if (updatedTransaction.type === TransactionType.SAVING && updatedTransaction.savingsGoalId) {
      // Apply new transaction amount to goal
      setSavingsGoals(prevGoals => prevGoals.map(goal => 
        goal.id === updatedTransaction.savingsGoalId
          ? { ...goal, currentAmount: goal.currentAmount + updatedTransaction.amount }
          : goal
      ));
    }
  };
  
  const deleteTransaction = (id: string) => {
    const transactionToDelete = transactions.find(t => t.id === id);
    setTransactions(prev => prev.filter(t => t.id !== id));

    if (transactionToDelete?.type === TransactionType.SAVING && transactionToDelete.savingsGoalId) {
      setSavingsGoals(prevGoals => prevGoals.map(goal =>
        goal.id === transactionToDelete.savingsGoalId
          ? { ...goal, currentAmount: goal.currentAmount - transactionToDelete.amount }
          : goal
      ));
    }
  };

  const addBudget = (budget: Omit<Budget, 'id'>) => {
    setBudgets(prev => [...prev, { ...budget, id: crypto.randomUUID() }]);
  };

  const updateBudget = (updatedBudget: Budget) => {
    setBudgets(prev => prev.map(b => b.id === updatedBudget.id ? updatedBudget : b));
  };

  const deleteBudget = (id: string) => {
    setBudgets(prev => prev.filter(b => b.id !== id));
  };

  const addSavingsGoal = (goal: Omit<SavingsGoal, 'id'>) => {
    setSavingsGoals(prev => [...prev, { ...goal, id: crypto.randomUUID() }]);
  };

  const updateSavingsGoal = (updatedGoal: SavingsGoal) => {
    setSavingsGoals(prev => prev.map(g => g.id === updatedGoal.id ? updatedGoal : g));
  };

  const deleteSavingsGoal = (id: string) => {
    setSavingsGoals(prev => prev.filter(g => g.id !== id));
  };

  const value = {
    transactions,
    setTransactions,
    addTransaction,
    updateTransaction,
    deleteTransaction,
    budgets,
    setBudgets,
    addBudget,
    updateBudget,
    deleteBudget,
    savingsGoals,
    setSavingsGoals,
    addSavingsGoal,
    updateSavingsGoal,
    deleteSavingsGoal,
    currency,
    setCurrency,
  };

  return <AppContext.Provider value={value}>{children}</AppContext.Provider>;
};

export const useAppContext = (): AppContextType => {
  const context = useContext(AppContext);
  if (context === undefined) {
    throw new Error('useAppContext must be used within an AppProvider');
  }
  return context;
};
