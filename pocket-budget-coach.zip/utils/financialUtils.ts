
import { Transaction, TransactionType } from "../types";

export const calculateTotal = (transactions: Transaction[], type: TransactionType): number => {
    return transactions
        .filter(t => t.type === type)
        .reduce((sum, t) => sum + t.amount, 0);
};

export const calculateBalance = (transactions: Transaction[]): number => {
    return transactions.reduce((balance, transaction) => {
        if (transaction.type === TransactionType.INCOME) {
            return balance + transaction.amount;
        }
        return balance - transaction.amount; // Expenses and Savings are outflows
    }, 0);
};
