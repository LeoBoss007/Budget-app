
import { BudgetPeriod } from '../types';

export const formatDate = (dateString: string): string => {
  return new Date(dateString).toLocaleDateString('en-US', {
    year: 'numeric',
    month: 'long',
    day: 'numeric',
  });
};

export const getISODate = (date: Date = new Date()): string => {
  return date.toISOString().split('T')[0];
};

export const getStartOfWeek = (date: Date): Date => {
  const d = new Date(date);
  const day = d.getDay();
  const diff = d.getDate() - day + (day === 0 ? -6 : 1); // adjust when day is sunday
  return new Date(d.setDate(diff));
};

export const getStartOfMonth = (date: Date): Date => {
    return new Date(date.getFullYear(), date.getMonth(), 1);
};


export const getPeriodStartDate = (period: BudgetPeriod): Date => {
    const now = new Date();
    if (period === BudgetPeriod.WEEKLY) {
        return getStartOfWeek(now);
    }
    return getStartOfMonth(now);
};
