
import { Currency } from '../types';
import { CURRENCIES } from '../constants';

export const formatCurrency = (amount: number, currency: Currency): string => {
  const symbol = CURRENCIES[currency];
  return `${symbol}${amount.toFixed(2)}`;
};
